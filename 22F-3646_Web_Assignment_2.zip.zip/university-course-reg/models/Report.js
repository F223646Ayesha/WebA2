const db = require("../config/db");

class Report {

    static async getStudentCourseData() {
        try {
            const [rows] = await db.query("SELECT * FROM student_course_registration");
            return rows;
        } catch (error) {
            throw error;
        }
    }

    static async getAvailableSeats() {
        try {
            const [rows] = await db.query("SELECT course_id, available_seats FROM courses");
            return rows;
        } catch (error) {
            throw error;
        }
    }

    static async getPrerequisiteCompletion() {
        try {
            const [rows] = await db.query("SELECT student_id, course_id, completed FROM prerequisites");
            return rows;
        } catch (error) {
            throw error;
        }
    }
}

module.exports = Report;
