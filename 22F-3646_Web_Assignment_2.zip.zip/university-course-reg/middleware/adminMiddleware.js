const jwt = require("jsonwebtoken");
const SECRET_KEY = "your-secret-key"; 

const adminMiddleware = (req, res, next) => {
    const authHeader = req.headers.authorization;

    console.log("🔍 Received Authorization Header:", authHeader); 

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ message: "Unauthorized: No token provided" });
    }

    const token = authHeader.split(" ")[1];

    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        console.log("✅ Decoded Token:", decoded); 

        if (decoded.userType !== "admin") {
            return res.status(403).json({ message: "Access denied. Admins only." });
        }

        req.user = decoded; // ✅ Attach user info to request
        next();
    } catch (error) {
        return res.status(403).json({ message: "Invalid or expired token" });
    }
};

module.exports = adminMiddleware;
