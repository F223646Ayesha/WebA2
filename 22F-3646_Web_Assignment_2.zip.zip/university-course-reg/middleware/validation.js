const { body, validationResult } = require('express-validator');

const validateLogin = [
    body('identifier').notEmpty().withMessage('Roll number or username is required'),
    body('password').notEmpty().withMessage('Password is required'),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    }
];

const validateCourseCreation = [
    body('courseName').notEmpty().withMessage('Course name is required'),
    body('department').notEmpty().withMessage('Department is required'),
    body('totalSeats').isInt({ min: 1 }).withMessage('Total seats must be at least 1'),
    body('level').notEmpty().withMessage('Level is required'),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    }
];

module.exports = { validateLogin, validateCourseCreation };
