const express = require("express");
const router = express.Router();
const studentController = require("../controllers/studentController");
const authMiddleware = require("../middleware/authMiddleware");

router.get("/dashboard", studentController.getDashboard);

router.get("/registered-courses", studentController.getRegisteredCourses);

router.get("/search-courses", studentController.searchCourses);

router.post("/register-course", studentController.registerCourse);

router.post("/deregister-course", studentController.deregisterCourse);

module.exports = router;
