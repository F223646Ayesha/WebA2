const express = require("express");
const router = express.Router();
const reportController = require("../controllers/reportController");


router.get("/", reportController.getReports); 
router.get("/students/:courseId", reportController.getStudentsForCourse); 
router.get("/available-seats", reportController.getCoursesWithAvailableSeats); 
router.get("/missing-prerequisites", reportController.getStudentsMissingPrerequisites); 

module.exports = router;
