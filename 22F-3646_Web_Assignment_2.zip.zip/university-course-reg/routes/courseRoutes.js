const express = require("express");
const router = express.Router();
const courseController = require("../controllers/courseController");

console.log("Course Controller:", courseController);

router.post("/add", courseController.addCourse);

router.put("/update/:courseId", courseController.updateCourse);

router.delete("/delete/:courseId", courseController.deleteCourse);

router.get("/", courseController.getAllCourses);

module.exports = router;
