const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();
const adminController = require("../controllers/adminController");
const { adminMiddleware, getStudents, addStudent, deleteStudent } = require("../controllers/adminController");

const SECRET_KEY = "your-secret-key";

const users = [
    { identifier: "admin", password: "admin123", userType: "admin" },
    { identifier: "student", password: "student123", userType: "student" }
];
router.get("/manageCourses", (req, res) => {
    res.render("admin/manageCourses");
});
router.get("/manageStudents", (req, res) => {
    res.render("admin/manageStudents");
});
router.get("/manageReports", (req, res) => {
    res.render("admin/manageReports");
});

router.get("/students", adminMiddleware, getStudents);
router.post("/students", adminMiddleware, addStudent);
router.delete("/students/:id", adminMiddleware, deleteStudent);

router.post("/login", (req, res) => {
    console.log("Received Login Request:", req.body);
    const { identifier, password, userType } = req.body;

    if (!identifier || !password || !userType) {
        return res.status(400).json({ success: false, message: "Missing credentials" });
    }

    const user = users.find(u => u.identifier === identifier && u.password === password && u.userType === userType);

    if (user) {

        const token = jwt.sign(
            { identifier: user.identifier, userType: user.userType },
            SECRET_KEY,
            { expiresIn: "2h" }
        );

        return res.json({ success: true, token });
    } else {
        return res.status(401).json({ success: false, message: "Invalid credentials" });
    }
});

module.exports = router;
