const express = require("express");
const router = express.Router();
const User = require("../models/User");

router.post("/login", async (req, res) => {
    console.log("🔍 Received Login Request:", req.body);

    const { identifier, password, userType } = req.body;

    if (!identifier || !password || !userType) {
        return res.status(400).json({ success: false, message: "Missing credentials" });
    }

    try {
        let user;
        if (userType === "admin") {
            user = await User.findOne({ username: identifier, role: "admin" });
        } else if (userType === "student") {
            user = await User.findOne({ rollNumber: identifier, role: "student" });
        }

        console.log("🔍 User Found:", user);

        if (!user) {
            return res.status(401).json({ success: false, message: "User not found" });
        }

        if (user.password !== password) {
            return res.status(401).json({ success: false, message: "Invalid credentials" });
        }

        res.json({ success: true, token: "fake-jwt-token", role: user.role });
    } catch (error) {
        console.error("❌ Error Accessing Database:", error);
        res.status(500).json({ success: false, message: "Internal Server Error" });
    }
});

module.exports = router;
