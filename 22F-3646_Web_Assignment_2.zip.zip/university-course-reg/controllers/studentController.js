const Course = require("../models/Course");
const Enrollment = require("../models/Enrollment");


exports.getDashboard = async (req, res) => {
    try {
        const studentId = req.user._id;

        const enrollments = await Enrollment.find({ studentId }).populate("courseId");

        res.render("student/dashboard", { enrollments });
    } catch (error) {
        console.error("Error loading student dashboard:", error);
        res.status(500).json({ success: false, message: "Server Error" });
    }
};

exports.getRegisteredCourses = async (req, res) => {
    try {
        const studentId = req.user._id;
        const enrollments = await Enrollment.find({ studentId }).populate("courseId");

        res.json({ success: true, courses: enrollments });
    } catch (error) {
        res.status(500).json({ success: false, message: "Server Error" });
    }
};


exports.searchCourses = async (req, res) => {
    try {
        const { department, level, time, days } = req.query;
        let query = {};

        if (department) query.department = department;
        if (level) query.level = level;
        if (time) query.time = time;
        if (days) query.days = { $in: days };

        const courses = await Course.find(query);
        res.json({ success: true, courses });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error fetching courses" });
    }
};

exports.registerCourse = async (req, res) => {
    try {
        const studentId = req.user._id;
        const { courseId } = req.body;

        const existingEnrollment = await Enrollment.findOne({ studentId, courseId });
        if (existingEnrollment) {
            return res.status(400).json({ success: false, message: "Already registered" });
        }

        await Enrollment.create({ studentId, courseId });
        res.json({ success: true, message: "Course registered successfully!" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error registering course" });
    }
};

exports.deregisterCourse = async (req, res) => {
    try {
        const studentId = req.user._id;
        const { courseId } = req.body;

        await Enrollment.findOneAndDelete({ studentId, courseId });
        res.json({ success: true, message: "Course deregistered successfully!" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error deregistering course" });
    }
};
