const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const User = require("../models/User");
require("dotenv").config();


exports.login = async (req, res) => {
    const { rollNumber, username, password } = req.body;
    
    try {
        let user;

        if (rollNumber) {
           
            user = await User.findOne({ rollNumber });
            if (!user) return res.status(401).json({ error: "Invalid roll number" });
        } else if (username) {
           
            user = await User.findOne({ username });
            if (!user || !(await bcrypt.compare(password, user.password))) {
                return res.status(401).json({ error: "Invalid credentials" });
            }
        } else {
            return res.status(400).json({ error: "Missing login credentials" });
        }

       
        const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: "2h" });

        res.json({ token, role: user.role });
    } catch (error) {
        res.status(500).json({ error: "Login error" });
    }
};


exports.verifyToken = (req, res) => {
    const token = req.headers.authorization;
    if (!token) return res.status(401).json({ error: "Access Denied" });

    jwt.verify(token.split(" ")[1], process.env.JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ error: "Invalid token" });
        res.json({ user });
    });
};
