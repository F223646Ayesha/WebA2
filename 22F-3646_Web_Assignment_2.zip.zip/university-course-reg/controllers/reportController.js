const Enrollment = require("../models/Enrollment");
const Course = require("../models/Course");
const User = require("../models/User");


exports.getReports = (req, res) => {
    res.render("admin/manageReports");
};


exports.getStudentsForCourse = async (req, res) => {
    try {
        const { courseId } = req.params;
        const enrollments = await Enrollment.find({ courseId }).populate("studentId", "name rollNumber");

        res.json({
            success: true,
            data: enrollments.map(enrollment => ({
                studentName: enrollment.studentId.name,
                rollNumber: enrollment.studentId.rollNumber
            }))
        });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error fetching students", error });
    }
};

exports.getCoursesWithAvailableSeats = async (req, res) => {
    try {
        const courses = await Course.find({ availableSeats: { $gt: 0 } });

        res.json({
            success: true,
            data: courses.map(course => ({
                courseName: course.name,
                courseCode: course.code,
                availableSeats: course.availableSeats
            }))
        });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error fetching courses", error });
    }
};

exports.getStudentsMissingPrerequisites = async (req, res) => {
    try {
        const students = await User.find({ role: "student" }).populate("enrollments");

        const studentsMissingPrerequisites = students.filter(student => {
            return student.enrollments.some(enrollment => 
                enrollment.course.prerequisites.some(prereq => 
                    !student.enrollments.some(e => e.courseId.equals(prereq))
                )
            );
        });

        res.json({
            success: true,
            data: studentsMissingPrerequisites.map(student => ({
                studentName: student.name,
                rollNumber: student.rollNumber
            }))
        });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error fetching students", error });
    }
};
