const jwt = require("jsonwebtoken");
const SECRET_KEY = process.env.JWT_SECRET;


const User = require("../models/User");


const getStudents = async (req, res) => {
    try {
        const students = await User.find({ role: "student" }).select("-password");
        res.json({ success: true, students });
    } catch (error) {
        res.status(500).json({ success: false, message: "Server Error" });
    }
};

const addStudent = async (req, res) => {
    try {
        const { name, rollNumber, password } = req.body;
        const existingStudent = await User.findOne({ rollNumber });
        if (existingStudent) {
            return res.status(400).json({ success: false, message: "Roll number already exists" });
        }
        const student = new User({ name, rollNumber, password, role: "student" });
        await student.save();
        res.json({ success: true, message: "Student added successfully!" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error adding student" });
    }
};

const deleteStudent = async (req, res) => {
    try {
        const studentId = req.params.id;
        const student = await User.findOne({ _id: studentId, role: "student" });
        if (!student) {
            return res.status(404).json({ success: false, message: "Student not found" });
        }
        await User.findByIdAndDelete(studentId);
        res.json({ success: true, message: "Student deleted successfully!" });
    } catch (error) {
        res.status(500).json({ success: false, message: "Error deleting student" });
    }
};

const adminMiddleware = (req, res, next) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ message: "Unauthorized: No token provided" });
    }

    const token = authHeader.split(" ")[1];

    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        if (decoded.userType !== "admin") {
            return res.status(403).json({ message: "Access denied. Admins only." });
        }
        req.user = decoded;
        next();
    } catch (error) {
        return res.status(403).json({ message: "Invalid or expired token" });
    }
};


module.exports = {
    adminMiddleware,
    getStudents,
    addStudent,
    deleteStudent
};
