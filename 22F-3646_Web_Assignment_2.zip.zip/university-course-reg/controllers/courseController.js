const Course = require("../models/Course");


const addCourse = async (req, res) => {
    try {
        const { name, code, department, seats, prerequisites } = req.body;

        const newCourse = new Course({
            name,
            code,
            department,
            seats,
            prerequisites
        });

        await newCourse.save();
        res.status(201).json({ message: "Course added successfully" });
    } catch (error) {
        res.status(500).json({ error: "Error adding course" });
    }
};


const updateCourse = async (req, res) => {
    try {
        const { courseId } = req.params;
        const updates = req.body;

        const updatedCourse = await Course.findByIdAndUpdate(courseId, updates, { new: true });

        if (!updatedCourse) return res.status(404).json({ error: "Course not found" });

        res.json({ message: "Course updated", updatedCourse });
    } catch (error) {
        res.status(500).json({ error: "Error updating course" });
    }
};


const deleteCourse = async (req, res) => {
    try {
        const { courseId } = req.params;

        const deletedCourse = await Course.findByIdAndDelete(courseId);
        if (!deletedCourse) return res.status(404).json({ error: "Course not found" });

        res.json({ message: "Course deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: "Error deleting course" });
    }
};


const getAllCourses = async (req, res) => {
    try {
        const courses = await Course.find();
        res.json(courses);
    } catch (error) {
        res.status(500).json({ error: "Error fetching courses" });
    }
};

// ✅ Properly export functions
module.exports = {
    addCourse,
    updateCourse,
    deleteCourse,
    getAllCourses
};
