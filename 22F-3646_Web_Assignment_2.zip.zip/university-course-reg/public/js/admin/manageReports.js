document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("courseReportForm").addEventListener("submit", async (e) => {
        e.preventDefault();
        const courseId = document.getElementById("courseId").value;
        const response = await fetch(`/reports/students-for-course/${courseId}`);
        const data = await response.json();
        document.getElementById("courseReportResult").innerHTML = JSON.stringify(data, null, 2);
    });

    document.getElementById("availableSeatsBtn").addEventListener("click", async () => {
        const response = await fetch(`/reports/available-seats`);
        const data = await response.json();
        document.getElementById("availableSeatsResult").innerHTML = JSON.stringify(data, null, 2);
    });

    document.getElementById("missingPrerequisitesBtn").addEventListener("click", async () => {
        const response = await fetch(`/reports/missing-prerequisites`);
        const data = await response.json();
        document.getElementById("missingPrerequisitesResult").innerHTML = JSON.stringify(data, null, 2);
    });
});
