document.addEventListener("DOMContentLoaded", async () => {
    const token = localStorage.getItem("token");

    if (!token) {
        alert("Unauthorized. Please log in.");
        window.location.href = "/index.html";
    }

    const response = await fetch("/api/admin/dashboard", {
        headers: { "Authorization": `Bearer ${token}` }
    });

    const data = await response.json();

    if (!response.ok) {
        alert("Session expired. Please log in again.");
        window.location.href = "/index.html";
    }
    
    document.getElementById("welcomeMessage").innerText = `Welcome, ${data.adminName}`;

    document.getElementById("manageCourses").addEventListener("click", () => {
        window.location.href = "/admin/manageCourses";
    });

    document.getElementById("manageStudents").addEventListener("click", () => {
        window.location.href = "/admin/manageStudents";
    });

    document.getElementById("viewReports").addEventListener("click", () => {
        window.location.href = "/admin/reports";
    });

    document.getElementById("logout").addEventListener("click", () => {
        localStorage.removeItem("token");
        window.location.href = "/index.html";
    });

    document.addEventListener("DOMContentLoaded", () => {
        fetchStudents();
        document.getElementById("addStudentForm").addEventListener("submit", addStudent);
    });
    
    async function fetchStudents() {
        try {
            const response = await fetch("/api/admin/students");
            const data = await response.json();
    
            if (data.success) {
                const list = document.getElementById("studentList");
                list.innerHTML = "";
    
                data.students.forEach(student => {
                    const li = document.createElement("li");
                    li.innerHTML = `
                        <strong>${student.name}</strong> - ${student.rollNumber}
                        <button onclick="deleteStudent('${student._id}')">Delete</button>
                    `;
                    list.appendChild(li);
                });
            }
        } catch (error) {
            console.error("Error fetching students:", error);
        }
    }
    
    async function addStudent(event) {
        event.preventDefault();
    
        const name = document.getElementById("name").value;
        const rollNumber = document.getElementById("rollNumber").value;
        const password = document.getElementById("password").value;
    
        try {
            const response = await fetch("/api/admin/students", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, rollNumber, password })
            });
    
            const data = await response.json();
            if (data.success) {
                fetchStudents();
            } else {
                alert(data.message);
            }
        } catch (error) {
            console.error("Error adding student:", error);
        }
    }
    
    async function deleteStudent(studentId) {
        try {
            const response = await fetch(`/api/admin/students/${studentId}`, {
                method: "DELETE"
            });
    
            const data = await response.json();
            if (data.success) {
                fetchStudents();
            } else {
                alert(data.message);
            }
        } catch (error) {
            console.error("Error deleting student:", error);
        }
    }
    
});
