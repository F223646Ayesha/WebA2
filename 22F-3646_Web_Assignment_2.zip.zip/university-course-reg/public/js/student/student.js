document.addEventListener("DOMContentLoaded", () => {
    fetchRegisteredCourses();
});

async function fetchRegisteredCourses() {
    try {
        const response = await fetch("/api/student/registered-courses", {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` }
        });
        const data = await response.json();
        
        if (data.success) {
            const list = document.getElementById("registered-courses");
            list.innerHTML = "";
            data.courses.forEach(enrollment => {
                const li = document.createElement("li");
                li.innerHTML = `
                    <strong>${enrollment.courseId.name}</strong> - ${enrollment.courseId.time}
                    <button onclick="deregisterCourse('${enrollment.courseId._id}')">Deregister</button>
                `;
                list.appendChild(li);
            });
        } else {
            console.error(data.message);
        }
    } catch (error) {
        console.error("Error fetching courses:", error);
    }
}

async function searchCourses() {
    const searchQuery = document.getElementById("search").value;
    try {
        const response = await fetch(`/api/student/search-courses?name=${searchQuery}`);
        const data = await response.json();

        if (data.success) {
            const list = document.getElementById("course-results");
            list.innerHTML = "";
            data.courses.forEach(course => {
                const li = document.createElement("li");
                li.innerHTML = `
                    <strong>${course.name}</strong> - ${course.time}
                    <button onclick="registerCourse('${course._id}')">Register</button>
                `;
                list.appendChild(li);
            });
        } else {
            console.error(data.message);
        }
    } catch (error) {
        console.error("Error searching courses:", error);
    }
}

async function registerCourse(courseId) {
    try {
        const response = await fetch("/api/student/register-course", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${localStorage.getItem("token")}`
            },
            body: JSON.stringify({ courseId })
        });
        const data = await response.json();
        
        if (data.success) {
            fetchRegisteredCourses();
        } else {
            alert(data.message);
        }
    } catch (error) {
        console.error("Error registering course:", error);
    }
}

async function deregisterCourse(courseId) {
    try {
        const response = await fetch("/api/student/deregister-course", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${localStorage.getItem("token")}`
            },
            body: JSON.stringify({ courseId })
        });
        const data = await response.json();
        
        if (data.success) {
            fetchRegisteredCourses();
        } else {
            alert(data.message);
        }
    } catch (error) {
        console.error("Error deregistering course:", error);
    }
}
