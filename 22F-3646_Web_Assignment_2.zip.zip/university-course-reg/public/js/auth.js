document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");

    if (loginForm) {
        loginForm.addEventListener("submit", async (event) => {
            event.preventDefault();

            const identifier = document.getElementById("identifier").value;
            const password = document.getElementById("password").value;
            const userType = "admin";

            console.log("Sending Login Request:", { identifier, password, userType }); // ✅ Debugging

            try {
                const response = await fetch("http://localhost:5000/api/auth/login", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ identifier, password, userType })
                });

                if (!response.ok) {
                    throw new Error(`HTTP Error: ${response.status}`);
                }
                
                
                const data = await response.json();

                console.log("Response Data:", data); // ✅ Debugging

                if (data.success) {
                    localStorage.setItem("token", data.token);
                    window.location.href = userType === "admin"
                    ? "/admin/dashboard"
                    : "/student/dashboard";

                } else {
                    alert(data.message);
                }

            } catch (error) {
                console.error("Login Error:", error);
                alert("Login failed. Check console for details.");
            }
        });
    }
});
