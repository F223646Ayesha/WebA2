# WebA2
# University Course Registration System  
A modern web application for managing course registration efficiently.  

## 📌 Features  
- Student & Admin login  
- Course selection with real-time availability  
- Advanced filtering & conflict detection  
- Admin management for students & courses  

## 🔗 GitHub Repository  
[University Course Registration]((https://github.com/F223646Ayesha/WebA2.git))
